//
//  Hello_WorldApp.swift
//  Hello World
//
//  Created by Tom Bredemeier on 8/26/21.
//

import SwiftUI

@main
struct Hello_WorldApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
